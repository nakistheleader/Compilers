/* Onoma arxeiou:       simple-bison-code.y
   Perigrafh:           Ypodeigma gia anaptyksh syntaktikou analyth me xrhsh tou ergaleiou Bison
   Syggrafeas:          Ergasthrio Metaglwttistwn, Tmhma Mhxanikwn Plhroforikhs kai Ypologistwn,
                        Panepisthmio Dytikhs Attikhs
   Sxolia:              To paron programma ylopoiei (me th xrhsh Bison) enan aplo syntaktiko analyth
			pou anagnwrizei ton pol/smo akeraiwn arithmwn (dekadikou systhmatos _xwris_
			proshmo) kai ektypwnei to apotelesma sthn othonh. Leitourgei autonoma, dhladh
			xwris Flex kai anagnwrizei kena	(space & tab) kai akeraious (dekadikou systhmatos) 
			ths glwssas Uni-CLIPS enw diaxeirizetai tous eidikous xarakthres neas grammhs '\n'
			(new line) kai 'EOF' (end of file). Kathara gia logous debugging typwnei sthn
			othonh otidhpote epistrefei h synarthsh yylex().
   Odhgies ekteleshs:   Dinete "make" xwris ta eisagwgika ston trexonta katalogo. Enallaktika:
			bison -o simple-bison-code.c simple-bison-code.y
                        gcc -o simple-bison-code simple-bison-code.c
                        ./simple-bison-code
*/

%{
/* Orismoi kai dhlwseis glwssas C. Otidhpote exei na kanei me orismo h arxikopoihsh
   metablhtwn & synarthsewn, arxeia header kai dhlwseis #define mpainei se auto to shmeio */
#include <stdio.h>
#include <stdlib.h>
int yylex(void);
void yyerror(char *);
%}


/* Orismos twn anagnwrisimwn lektikwn monadwn. */
%union {
    int ival;
    float fval;
}

%token <ival> INTCONST
%token <fval> FLOAT
%token MULT DIV PLUS MINUS EQUALS NEWLINE LEFT_PAR RIGHT_PAR STORED_WORD DELIMITER VARIABLE FACT_RULE_NAME COMMENT STRING OPERATOR UNKNOWN_TOKEN

%type <fval> expr

/* Orismos proteraiothtwn sta tokens */
%left PLUS MINUS
%left MULT DIV



%%

/* Orismos twn grammatikwn kanonwn. Kathe fora pou antistoixizetai enas grammatikos
   kanonas me ta dedomena eisodou, ekteleitai o kwdikas C pou brisketai anamesa sta
   agkistra. H anamenomenh syntaksh einai:
				onoma : kanonas { kwdikas C } */
program:
        program expr NEWLINE    { printf("\nMathimatic Expression."); }
	|program deffacts  NEWLINE      { printf("\nDeffacts Definition.");  }
	//|program defrule    NEWLINE      { printf("\nDefrule Definition.");  }
	//|program test        NEWLINE     { printf("\nTest Function.");  }
	//|program printout   NEWLINE      { printf("\nPrint Function.");  }
//	|program read      NEWLINE       { printf("\nRead Function.");  }
	//|program bind    NEWLINE         { printf("\nBind Function.");  }
	//|program error	  NEWLINE        { printf("\nSyntax error"); }
	|
	;

expr:
        INTCONST           { /*$$ = $1; */}
        VARIABLE        { /*$$ = $1;*/}
        |LEFT_PAR MULT expr expr_list  RIGHT_PAR  { /*$$ = $2 * $3; */}
	|LEFT_PAR DIV expr expr_list   RIGHT_PAR { /* $$ = $2 / $3; */}
	|LEFT_PAR PLUS expr expr_list RIGHT_PAR{ /* $$ = $2 + $3; */}
	|LEFT_PAR MINUS expr expr_list  RIGHT_PAR{ /* $$ = $2 - $3; */}
        |LEFT_PAR EQUALS expr expr_list RIGHT_PAR { /* $$ = $2; */}
        ;

expr_list:
        expr { /*$$ = $1;*/ }
        |expr_list expr { } /* Combine results of expressions */
        ;

deffacts:
        LEFT_PAR "deffacts" FACT_RULE_NAME facts RIGHT_PAR
        {
            printf("Deffacts: \n");
        }

facts:
        LEFT_PAR FACT_RULE_NAME facts_list RIGHT_PAR
        |facts LEFT_PAR FACT_RULE_NAME facts_list RIGHT_PAR


facts_list:
        expr { printf("Fact: \n"); }
        |facts_list expr { printf("Fact:\n"); }
        ;
%%


int parentheses_cnt = 0;

/* H synarthsh yyerror xrhsimopoieitai gia thn anafora sfalmatwn. Sygkekrimena kaleitai
   apo thn yyparse otan yparksei kapoio syntaktiko lathos. Sthn parakatw periptwsh h
   synarthsh epi ths ousias typwnei mhnyma lathous sthn othonh. */
void yyerror(char *s) {
        fprintf(stderr, "Error: %s\n", s);
}


/* H synarthsh main pou apotelei kai to shmeio ekkinhshs tou programmatos.
   Sthn sygkekrimenh periptwsh apla kalei thn synarthsh yyparse tou Bison
   gia na ksekinhsei h syntaktikh analysh. */
int main(void)  {
      //  yydebug = 1; // Enable debugging output
        yyparse();
        return 0;
}
